package com.church.domain;


import jakarta.persistence.*;
import java.time.LocalDateTime;


@Entity
@Table(name = "page_contents", uniqueConstraints = @UniqueConstraint(columnNames = "slug"))
public class PageContent {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    @Column(nullable = false, length = 100)
    private String slug; // 예: home.welcome, about.body, ministries.body


    @Column(nullable = false, length = 120)
    private String title; // 편집 화면 제목


    @Lob
    @Column(nullable = false)
    private String content; // HTML 허용 (관리자만 편집)


    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;


    @PrePersist
    public void prePersist(){
        createdAt = LocalDateTime.now();
        updatedAt = createdAt;
    }


    @PreUpdate
    public void preUpdate(){
        updatedAt = LocalDateTime.now();
    }


    // getters/setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getSlug() { return slug; }
    public void setSlug(String slug) { this.slug = slug; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(LocalDateTime updatedAt) { this.updatedAt = updatedAt; }
}