package com.church.domain;


import jakarta.persistence.*;
import java.time.LocalDateTime;


@Entity
public class Notice {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    @Column(nullable = false)
    private String title;


    @Lob
    @Column(nullable = false)
    private String content;


    private boolean pinned = false; // 상단 고정 여부


    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;


    @PrePersist
    public void prePersist(){
        createdAt = LocalDateTime.now();
        updatedAt = createdAt;
    }


    @PreUpdate
    public void preUpdate(){
        updatedAt = LocalDateTime.now();
    }


    // getters/setters
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public String getTitle(){return title;}
    public void setTitle(String title){this.title=title;}
    public String getContent(){return content;}
    public void setContent(String content){this.content=content;}
    public boolean isPinned(){return pinned;}
    public void setPinned(boolean pinned){this.pinned=pinned;}
    public LocalDateTime getCreatedAt(){return createdAt;}
    public void setCreatedAt(LocalDateTime createdAt){this.createdAt=createdAt;}
    public LocalDateTime getUpdatedAt(){return updatedAt;}
    public void setUpdatedAt(LocalDateTime updatedAt){this.updatedAt=updatedAt;}
}