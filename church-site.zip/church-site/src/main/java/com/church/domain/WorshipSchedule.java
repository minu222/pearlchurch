package com.church.domain;


import jakarta.persistence.*;
import java.time.DayOfWeek;
import java.time.LocalTime;


@Entity
public class WorshipSchedule {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    @Column(nullable = false)
    private String name; // 주일예배, 수요예배 등


    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private DayOfWeek dayOfWeek; // 요일


    @Column(nullable = false)
    private LocalTime time; // 시작 시간


    private String location; // 본당, 소예배실 등
    private String note; // 비고


    // getters/setters
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public String getName(){return name;}
    public void setName(String name){this.name=name;}
    public DayOfWeek getDayOfWeek(){return dayOfWeek;}
    public void setDayOfWeek(DayOfWeek dayOfWeek){this.dayOfWeek=dayOfWeek;}
    public LocalTime getTime(){return time;}
    public void setTime(LocalTime time){this.time=time;}
    public String getLocation(){return location;}
    public void setLocation(String location){this.location=location;}
    public String getNote(){return note;}
    public void setNote(String note){this.note=note;}
}