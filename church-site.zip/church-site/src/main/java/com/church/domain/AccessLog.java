package com.church.domain;


import jakarta.persistence.*;
import java.time.LocalDateTime;


@Entity
@Table(name = "access_logs")
public class AccessLog {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    private Long userId; // AdminUser id
    private String churchNo; // 로그인 ID
    private String displayName; // 이름 스냅샷


    private String ip;
    @Column(length = 400)
    private String userAgent;


    private LocalDateTime loginAt; // 로그인 시각


    // getters/setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getChurchNo() { return churchNo; }
    public void setChurchNo(String churchNo) { this.churchNo = churchNo; }
    public String getDisplayName() { return displayName; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }
    public String getIp() { return ip; }
    public void setIp(String ip) { this.ip = ip; }
    public String getUserAgent() { return userAgent; }
    public void setUserAgent(String userAgent) { this.userAgent = userAgent; }
    public LocalDateTime getLoginAt() { return loginAt; }
    public void setLoginAt(LocalDateTime loginAt) { this.loginAt = loginAt; }
}