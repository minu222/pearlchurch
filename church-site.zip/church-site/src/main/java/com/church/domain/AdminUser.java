package com.church.domain;


import jakarta.persistence.*;


@Entity
@Table(name = "admin_users")
public class AdminUser {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    @Column(nullable = false, unique = true, length = 32)
    private String churchNo; // 교회에서 부여한 번호(로그인 ID)


    @Column(nullable = false, length = 64)
    private String displayName; // 관리자 이름 (표시용)


    @Column(nullable = false, length = 200)
    private String password; // BCrypt 암호


    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private Role role = Role.ADMIN; // 현재는 ADMIN만 사용


    public enum Role { ADMIN }


    // getters/setters
    public Long getId() { return id; }
    public String getChurchNo() { return churchNo; }
    public String getDisplayName() { return displayName; }
    public String getPassword() { return password; }
    public Role getRole() { return role; }
    public void setId(Long id) { this.id = id; }
    public void setChurchNo(String churchNo) { this.churchNo = churchNo; }
    public void setDisplayName(String displayName) { this.displayName = displayName; }
    public void setPassword(String password) { this.password = password; }
    public void setRole(Role role) { this.role = role; }
}