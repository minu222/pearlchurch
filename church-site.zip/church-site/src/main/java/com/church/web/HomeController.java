package com.church.web;


import com.church.service.PageContentService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;


@Controller
public class HomeController {


    private final PageContentService contents;


    public HomeController(PageContentService contents){
        this.contents = contents;
    }


    @GetMapping("/")
    public String index(Model model) {
        return "index";
    }


    @GetMapping("/about")
    public String about(@RequestParam(value = "tab", defaultValue = "church") String tab, Model model) {
        model.addAttribute("active", "about");
        model.addAttribute("title", "교회소개");

        // 탭 → 슬러그/제목 매핑
        Map<String, String> slugMap = Map.of(
                "church", "about.church",
                "people", "about.people",
                "vision", "about.vision",
                "directions", "about.directions"
        );
        Map<String, String> titleMap = Map.of(
                "church", "우리 교회 소개",
                "people", "섬기는 사람",
                "vision", "교회 비전",
                "directions", "오시는 길"
        );
        if (!slugMap.containsKey(tab)) tab = "church";
        String slug = slugMap.get(tab);
        String heading = titleMap.get(tab);

        // 기본 콘텐츠 (최초 생성용)
        String defaultHtml = switch (tab) {
            case "people" -> "<h3>목사님</h3><p>약력/사역 소개</p><h3>사모님</h3><p>사역 소개</p><h3>장로님</h3><ul><li>장로 A</li></ul><h3>선교사님</h3><ul><li>선교사 A</li></ul>";
            case "vision" -> "<p>말씀, 예배, 선교, 다음세대 등 교회의 핵심 비전을 정리하세요.</p>";
            case "directions" -> "<p>주소: (예) 서울시 ○○구 ○○로 123</p><p>대중교통/주차 안내를 적어주세요.</p>";
            default -> "<p>교회 연혁, 예배와 사역, 공동체 소개 등의 내용을 입력하세요.</p>";
        };

        // 상단 인사말(공통) + 현재 탭 본문
        model.addAttribute("intro", contents.getOrCreate(
                "about.intro", "교회소개 인사말",
                "<p>우리교회는 말씀과 사랑으로 지역과 열방을 섬기는 공동체입니다.</p>"
        ));
        model.addAttribute("pc", contents.getOrCreate(slug, heading + " 본문", defaultHtml));

        // 뷰에 상태 전달
        model.addAttribute("tab", tab);
        model.addAttribute("slug", slug);
        model.addAttribute("heading", heading);
        return "about";
    }



    @GetMapping("/ministries")
    public String ministries(Model model) {
        model.addAttribute("active", "ministries");
        model.addAttribute("title", "사역소개");
        model.addAttribute("c_ministries_body", contents.getOrCreate(
                "ministries.body", "사역소개 본문",
                "<ul><li>찬양팀</li><li>교육부</li><li>선교부</li></ul>"
        ));
        return "ministries";
    }
}