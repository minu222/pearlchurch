package com.church.web;


import com.church.domain.WorshipSchedule;
import com.church.repository.WorshipScheduleRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


@Controller
public class ScheduleController {


    private final WorshipScheduleRepository repo;


    public ScheduleController(WorshipScheduleRepository repo){
        this.repo = repo;
    }


    // 공개 일정 페이지
    @GetMapping("/schedule")
    public String schedule(Model model){
        model.addAttribute("active", "schedule");
        model.addAttribute("title", "예배일정");
        model.addAttribute("list", repo.findAllByOrderByDayOfWeekAscTimeAsc());
        return "schedule"; // 공개용 템플릿
    }


    // 관리자: 목록
    @GetMapping("/admin/schedule")
    public String adminList(Model model){
        model.addAttribute("title", "예배일정 관리");
        model.addAttribute("list", repo.findAllByOrderByDayOfWeekAscTimeAsc());
        model.addAttribute("item", new WorshipSchedule());
        return "admin/schedule/list";
    }


    // 관리자: 등록
    @PostMapping("/admin/schedule")
    public String create(@ModelAttribute WorshipSchedule form){
        repo.save(form);
        return "redirect:/admin/schedule";
    }


    // 관리자: 수정 폼
    @GetMapping("/admin/schedule/{id}/edit")
    public String editForm(@PathVariable Long id, Model model){
        model.addAttribute("title", "예배일정 수정");
        model.addAttribute("item", repo.findById(id).orElseThrow());
        return "admin/schedule/form";
    }


    // 관리자: 수정 처리
    @PostMapping("/admin/schedule/{id}")
    public String update(@PathVariable Long id, @ModelAttribute WorshipSchedule form){
        WorshipSchedule w = repo.findById(id).orElseThrow();
        w.setName(form.getName());
        w.setDayOfWeek(form.getDayOfWeek());
        w.setTime(form.getTime());
        w.setLocation(form.getLocation());
        w.setNote(form.getNote());
        repo.save(w);
        return "redirect:/admin/schedule";
    }


    // 관리자: 삭제
    @PostMapping("/admin/schedule/{id}/delete")
    public String delete(@PathVariable Long id){
        repo.deleteById(id);
        return "redirect:/admin/schedule";
    }
}