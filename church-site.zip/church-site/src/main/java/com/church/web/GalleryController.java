package com.church.web;

import com.church.gallery.GalleryCategory;
import com.church.gallery.GalleryImage;
import com.church.gallery.GalleryPost;
import com.church.gallery.GalleryService;
import com.church.repository.GalleryPostRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class GalleryController {

    private final GalleryPostRepository repo;
    private final GalleryService galleryService;


    public GalleryController(GalleryPostRepository repo,
                             GalleryService galleryService) {
        this.repo = repo;
        this.galleryService = galleryService;
    }

    // 갤러리 목록 + 검색 + 분류 + 페이징
    @GetMapping("/gallery")
    public String list(
            @RequestParam(value = "q", defaultValue = "") String q,
            @RequestParam(value = "category", required = false) GalleryCategory category,
            @RequestParam(value = "page", defaultValue = "0") int page,
            Model model
    ) {

        PageRequest pageable = PageRequest.of(page, 9); // 9개씩 카드형

        Page<GalleryPost> result;
        if (category == null) {
            result = repo.findByTitleContainingIgnoreCaseOrderByCreatedAtDesc(q, pageable);
        } else {
            result = repo.findByCategoryAndTitleContainingIgnoreCaseOrderByCreatedAtDesc(category, q, pageable);
        }

        // 썸네일 편의용: 대표 이미지 경로 추출
        // (업로드 저장 경로를 /uploads/gallery/<fileName> 라고 가정)
        model.addAttribute("page", result.map(post -> {
            String cover = (post.getImages().isEmpty())
                    ? null
                    : post.getImages().get(0).getFileName();
            // view 단에서 post.coverImagePath 로 접근 가능하도록 임시 래핑
            post.getImages(); // lazy init hint
            return new GalleryListView(
                    post.getId(),
                    post.getTitle(),
                    post.getCategory(),
                    post.getEventDate(),
                    cover
            );
        }));

        model.addAttribute("active", "gallery");
        model.addAttribute("title", "갤러리");

        model.addAttribute("q", q);
        model.addAttribute("category", category);

        return "gallery";
    }

    // 업로드 폼 (관리자만)
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping("/gallery/new")
    public String newForm(Model model) {
        model.addAttribute("active", "gallery");
        model.addAttribute("title", "갤러리 업로드");
        model.addAttribute("categories", GalleryCategory.values());
        return "admin/gallery/gallery-form";
    }

    // DTO-like 보조 record
    public record GalleryListView(
            Long id,
            String title,
            GalleryCategory category,
            java.time.LocalDateTime eventDate,
            String coverImagePath
    ) {}



    // --- 여기 아래를 새로 추가 ---
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/gallery/new")
    public String create(
            @RequestParam("title") String title,
            @RequestParam("category") GalleryCategory category,
            @RequestParam(value = "eventDate", required = false)
            @DateTimeFormat(pattern = "yyyy-MM-dd'T'HH:mm")
            java.time.LocalDateTime eventDate,
            @RequestParam(value = "images", required = false) MultipartFile[] images,
            RedirectAttributes redirectAttributes
    ) {
        try {
            GalleryPost saved = galleryService.createPost(
                    title,
                    category,
                    eventDate,
                    images
            );
            redirectAttributes.addFlashAttribute("msg", "갤러리가 등록되었습니다.");
            return "redirect:/gallery?id=" + saved.getId(); // 상세로 보내고 싶으면 이렇게
            // or 목록으로 보내려면: return "redirect:/gallery";
        } catch (Exception e) {
            e.printStackTrace();
            redirectAttributes.addFlashAttribute("error", "업로드 중 오류가 발생했습니다.");
            return "redirect:/gallery/new";
        }
    }


    @GetMapping("/gallery/{id}")
    public String detail(
            @PathVariable("id") Long id,
            Model model
    ) {
        GalleryPost post = repo.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));

        // 이미지 URL 목록 만들기 (브라우저에서 바로 접근 가능하도록)
        // /uploads/gallery/{savedName} 이런 경로로 보여줄 거야.
        List<String> imageUrls = post.getImages().stream()
                .sorted(java.util.Comparator.comparing(GalleryImage::getSortOrder, java.util.Comparator.nullsLast(Integer::compareTo)))
                .map(img -> "/uploads/gallery/" + img.getFileName())
                .toList();

        model.addAttribute("post", post);
        model.addAttribute("imageUrls", imageUrls);

        model.addAttribute("active", "gallery");
        model.addAttribute("title", "갤러리 상세");

        return "admin/gallery/gallery-detail";
    }
}
