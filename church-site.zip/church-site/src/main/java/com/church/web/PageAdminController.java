package com.church.web;


import com.church.domain.PageContent;
import com.church.repository.PageContentRepository;
import com.church.service.PageContentService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


import java.util.List;


@Controller
@RequestMapping("/admin/pages")
public class PageAdminController {


    private final PageContentRepository repo;
    private final PageContentService service;


    public PageAdminController(PageContentRepository repo, PageContentService service){
        this.repo = repo; this.service = service;
    }


    @GetMapping
    public String list(Model model){
        List<PageContent> list = repo.findAll();
        model.addAttribute("title", "페이지 콘텐츠 관리");
        model.addAttribute("list", list);
        model.addAttribute("item", new PageContent());
        return "admin/pages/list";
    }


    @PostMapping
    public String create(@ModelAttribute PageContent form){
        service.getOrCreate(form.getSlug(), form.getTitle(), form.getContent() == null ? "" : form.getContent());
        return "redirect:/admin/pages";
    }


    @GetMapping("/{slug}/edit")
    public String edit(@PathVariable String slug, Model model){
        PageContent pc = service.get(slug);
        if (pc == null) return "redirect:/admin/pages";
        model.addAttribute("title", pc.getTitle() + " 편집");
        model.addAttribute("pc", pc);
        return "admin/pages/form";
    }


    // src/main/java/com/church/web/PageAdminController.java (update 메서드 교체)
    @PostMapping("/{slug}")
    public String update(@PathVariable String slug,
                         @ModelAttribute com.church.domain.PageContent form,
                         @org.springframework.web.bind.annotation.RequestParam(value = "returnTo", required = false) String returnTo) {
        service.update(slug, form.getTitle(), form.getContent());
// 안전한 로컬 리다이렉트만 허용 (오픈리다이렉트 방지)
        if (returnTo != null && !returnTo.isBlank() && returnTo.startsWith("/")) {
            return "redirect:" + returnTo;
        }
        return "redirect:/admin/pages";
    }


    @PostMapping("/{id}/delete")
    public String delete(@PathVariable Long id){
        repo.deleteById(id);
        return "redirect:/admin/pages";
    }
}