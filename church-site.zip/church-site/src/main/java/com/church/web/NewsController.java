package com.church.web;


import com.church.domain.Notice;
import com.church.repository.NoticeRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;


import jakarta.validation.Valid;
import java.util.Optional;


@Controller
public class NewsController {


    private final NoticeRepository noticeRepository;


    public NewsController(NoticeRepository noticeRepository) {
        this.noticeRepository = noticeRepository;
    }


    @GetMapping("/news")
    public String news(Model model,
                       @RequestParam(value="q", required=false) String q,
                       @RequestParam(value="page", defaultValue="0") int page,
                       @RequestParam(value="size", defaultValue="8") int size){
        Sort sort = Sort.by(Sort.Order.desc("pinned"), Sort.Order.desc("createdAt"));
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<Notice> p = (q!=null && !q.isBlank())
                ? noticeRepository.findByTitleContainingIgnoreCaseOrContentContainingIgnoreCase(q, q, pageable)
                : noticeRepository.findAll(pageable);
        model.addAttribute("active","news");
        model.addAttribute("title","소식/공지");
        model.addAttribute("page", p);
        model.addAttribute("q", q);
        return "news";
    }

    // 공개 상세
    @GetMapping("/news/{id}")
    public String newsDetail(@PathVariable Long id, Model model) {
        Optional<Notice> notice = noticeRepository.findById(id);
        if (notice.isEmpty()) return "redirect:/news";
        model.addAttribute("active", "news");
        model.addAttribute("title", notice.get().getTitle());
        model.addAttribute("notice", notice.get());
        return "news-detail";
    }


    @GetMapping("/admin/notices")
    public String adminList(Model model,
                            @RequestParam(value="q", required=false) String q,
                            @RequestParam(value="page", defaultValue="0") int page,
                            @RequestParam(value="size", defaultValue="10") int size){
        Sort sort = Sort.by(Sort.Order.desc("pinned"), Sort.Order.desc("createdAt"));
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<Notice> p = (q!=null && !q.isBlank())
                ? noticeRepository.findByTitleContainingIgnoreCaseOrContentContainingIgnoreCase(q, q, pageable)
                : noticeRepository.findAll(pageable);
        model.addAttribute("active","news");
        model.addAttribute("title","공지 관리");
        model.addAttribute("page", p);
        model.addAttribute("q", q);
        return "admin/notice/list";
    }


    // 관리자: 등록 폼
    @GetMapping("/admin/notices/new")
    public String newForm(Model model) {
        model.addAttribute("title", "공지 등록");
        model.addAttribute("notice", new Notice());
        return "admin/notice/form";
    }


    // 관리자: 등록 처리
    @PostMapping("/admin/notices")
    public String create(@ModelAttribute @Valid Notice notice, BindingResult binding) {
        if (binding.hasErrors()) return "admin/notice/form";
        noticeRepository.save(notice);
        return "redirect:/admin/notices";
    }

    // 관리자: 수정 폼
    @GetMapping("/admin/notices/{id}/edit")
    public String editForm(@PathVariable Long id, Model model){
        Notice n = noticeRepository.findById(id).orElseThrow();
        model.addAttribute("title", "공지 수정");
        model.addAttribute("notice", n);
        return "admin/notice/form";
    }


    // 관리자: 수정 처리
    @PostMapping("/admin/notices/{id}")
    public String update(@PathVariable Long id, @ModelAttribute Notice form){
        Notice n = noticeRepository.findById(id).orElseThrow();
        n.setTitle(form.getTitle());
        n.setContent(form.getContent());
        n.setPinned(form.isPinned());
        noticeRepository.save(n);
        return "redirect:/admin/notices";
    }


    // 관리자: 삭제
    @PostMapping("/admin/notices/{id}/delete")
    public String delete(@PathVariable Long id){
        noticeRepository.deleteById(id);
        return "redirect:/admin/notices";
    }
}

