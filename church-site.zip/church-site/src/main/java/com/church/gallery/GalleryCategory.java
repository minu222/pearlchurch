package com.church.gallery;

public enum GalleryCategory {
    CHURCH_EVENT, // 교회 및 행사
    FREE          // 자유
}

