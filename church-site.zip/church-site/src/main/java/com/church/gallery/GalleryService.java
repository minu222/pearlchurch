package com.church.gallery;

import com.church.repository.GalleryPostRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class GalleryService {

    private final GalleryPostRepository postRepo;

    public GalleryService(GalleryPostRepository postRepo) {
        this.postRepo = postRepo;
    }

    /**
     * 새 갤러리 글 + 이미지 파일들 저장
     */
    public GalleryPost createPost(
            String title,
            GalleryCategory category,
            LocalDateTime eventDate,
            MultipartFile[] images
    ) throws IOException {

        // 1) 게시글 엔티티부터 만든다
        GalleryPost post = new GalleryPost();
        post.setTitle(title);
        post.setCategory(category);
        post.setEventDate(eventDate);
        // createdAt / updatedAt 은 @PrePersist 에서 자동 세팅됨

        // 2) 이미지들 실제 파일 저장하고 GalleryImage로 연결
        //    업로드 경로: 프로젝트 루트 기준 "uploads/gallery"
        Path uploadRoot = Paths.get("uploads/gallery").toAbsolutePath().normalize();
        Files.createDirectories(uploadRoot); // 폴더 없으면 생성

        int sort = 0;
        if (images != null) {
            for (MultipartFile file : images) {
                if (file.isEmpty()) continue;

                // 원본 확장자 유지해서 UUID로 저장
                String originalName = file.getOriginalFilename();
                String ext = "";
                if (originalName != null && originalName.contains(".")) {
                    ext = originalName.substring(originalName.lastIndexOf("."));
                }
                String savedName = UUID.randomUUID().toString() + ext;

                Path target = uploadRoot.resolve(savedName);
                Files.copy(file.getInputStream(), target);

                GalleryImage img = new GalleryImage();
                img.setOriginalName(originalName);
                img.setFileName(savedName); // 이걸로 나중에 /uploads/gallery/{fileName} 접근
                img.setSortOrder(sort++);
                img.setPost(post);

                post.getImages().add(img);
            }
        }

        // 3) 저장 (cascade = ALL 이라 이미지도 같이 저장됨)
        return postRepo.save(post);
    }
}
