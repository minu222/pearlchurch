package com.church.gallery;

import jakarta.persistence.*;

@Entity
public class GalleryImage {

    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String fileName;      // 실제 저장된 파일명 (ex: 9f2a7c.jpg)
    private String originalName;  // 원본명 (ex: IMG_1234.jpg)
    private Integer sortOrder = 0; // 썸네일 정렬 우선순위

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "post_id")
    private GalleryPost post;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getOriginalName() {
        return originalName;
    }

    public void setOriginalName(String originalName) {
        this.originalName = originalName;
    }

    public Integer getSortOrder() {
        return sortOrder;
    }

    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }

    public GalleryPost getPost() {
        return post;
    }

    public void setPost(GalleryPost post) {
        this.post = post;
    }
// getter/setter ...
}
