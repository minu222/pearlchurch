package com.church.repository;

import com.church.gallery.GalleryCategory;
import com.church.gallery.GalleryPost;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GalleryPostRepository extends JpaRepository<GalleryPost, Long> {

    // 검색어만 (카테고리 전체)
    Page<GalleryPost> findByTitleContainingIgnoreCaseOrderByCreatedAtDesc(
            String q,
            Pageable pageable
    );

    // 카테고리 + 검색어
    Page<GalleryPost> findByCategoryAndTitleContainingIgnoreCaseOrderByCreatedAtDesc(
            GalleryCategory category,
            String q,
            Pageable pageable
    );
}
