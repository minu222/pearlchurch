package com.church.repository;


import com.church.domain.WorshipSchedule;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;


public interface WorshipScheduleRepository extends JpaRepository<WorshipSchedule, Long> {
    List<WorshipSchedule> findAllByOrderByDayOfWeekAscTimeAsc();
}