package com.church.config;


import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


import java.nio.file.Path;
import java.nio.file.Paths;


@Configuration
public class WebConfig implements WebMvcConfigurer {



    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {

        // 실제 로컬 경로
        Path uploadDir = Paths.get("uploads/gallery").toAbsolutePath().normalize();
        String uploadPath = uploadDir.toUri().toString(); // file:///... 형식

        registry.addResourceHandler("/uploads/gallery/**")
                .addResourceLocations(uploadPath);
    }
}