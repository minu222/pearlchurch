package com.church.config;


import com.church.domain.AdminUser;
import com.church.repository.AdminUserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;


@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner seedAdmin(
            AdminUserRepository repo,
            PasswordEncoder enc,
            // properties with env fallback
            @Value("${admin.seed.enabled:true}") boolean enabled,
            @Value("${admin.seed.churchNo:0001}") String seedNo,
            @Value("${admin.seed.displayName:관리자}") String seedName,
            @Value("${admin.seed.password:admin1234}") String seedPw,
            @Value("${admin.seed.update-if-different:true}") boolean updateIfDifferent
    ) {
        return args -> {
            if (!enabled) return;

            repo.findByChurchNo(seedNo).ifPresentOrElse(u -> {
                boolean changed = false;

                // 비밀번호가 다르면(또는 DB에 평문으로 저장돼 있던 경우 포함) -> 재해시 후 교체
                if (!enc.matches(seedPw, u.getPassword())) {
                    u.setPassword(enc.encode(seedPw));
                    changed = true;
                    System.out.println("[AdminSeed] password updated for churchNo=" + seedNo);
                }

                // 표시 이름이 바뀌었으면 업데이트
                if (!seedName.equals(u.getDisplayName())) {
                    u.setDisplayName(seedName);
                    changed = true;
                }

                if (updateIfDifferent && changed) {
                    repo.save(u);
                }
            }, () -> {
                AdminUser u = new AdminUser();
                u.setChurchNo(seedNo);
                u.setDisplayName(seedName);
                u.setPassword(enc.encode(seedPw)); // 반드시 BCrypt 해시 저장
                repo.save(u);
                System.out.println("[AdminSeed] created admin churchNo=" + seedNo);
            });
        };
    }




    @Bean
    org.springframework.boot.CommandLineRunner seedPageContents(
            com.church.repository.PageContentRepository repo
    ){
        return args -> {
            createIfMissing(repo, "home.welcome", "홈 인사말",
                    "<p>우리교회 홈페이지에 오신 것을 환영합니다.</p>");
            createIfMissing(repo, "about.body", "교회소개 본문",
                    "<h2>교회 비전</h2><p>지역과 열방을 섬기는 공동체</p>");
            createIfMissing(repo, "ministries.body", "사역소개 본문",
                    "<ul><li>찬양팀</li><li>교육부</li><li>선교부</li></ul>");
// 필요 시 아래 추가 가능: news.top, gallery.top, schedule.top 등
        };
    }
    // DataInitializer 안 어딘가에 추가(예: 기존 seedPageContents와 함께)
    @Bean
    org.springframework.boot.CommandLineRunner seedAboutSections(
            com.church.repository.PageContentRepository repo
    ){
        return args -> {
            createIfMissing(repo, "about.intro",      "교회소개 인사말",
                    "<p>우리교회는 말씀과 사랑으로 지역과 열방을 섬기는 공동체입니다.</p>");
            createIfMissing(repo, "about.church",     "우리 교회 소개",
                    "<p>교회 연혁, 예배와 사역, 공동체 소개 등의 내용을 입력하세요.</p>");
            createIfMissing(repo, "about.people",     "섬기는 사람",
                    "<h3>목사님</h3><p>이름, 약력, 사역 소개</p><h3>사모님</h3><p>사역 소개</p><h3>장로님</h3><ul><li>장로 A</li><li>장로 B</li></ul><h3>선교사님</h3><ul><li>선교사 A</li><li>선교사 B</li></ul>");
            createIfMissing(repo, "about.vision",     "교회 비전",
                    "<p>말씀, 예배, 선교, 다음세대 등의 핵심 비전을 정리하세요.</p>");
            createIfMissing(repo, "about.directions", "오시는 길",
                    "<p>주소: (예) 서울시 ○○구 ○○로 123, 우리교회</p><p>대중교통/주차 안내를 적어주세요.</p>");
        };
    }
    private static void createIfMissing(com.church.repository.PageContentRepository repo,
                                        String slug, String title, String html){
        repo.findBySlug(slug).orElseGet(() -> {
            com.church.domain.PageContent pc = new com.church.domain.PageContent();
            pc.setSlug(slug); pc.setTitle(title); pc.setContent(html);
            return repo.save(pc);
        });
    }

}