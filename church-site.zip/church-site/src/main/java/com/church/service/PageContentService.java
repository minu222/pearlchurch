package com.church.service;


import com.church.domain.PageContent;
import com.church.repository.PageContentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
public class PageContentService {


    private final PageContentRepository repo;


    public PageContentService(PageContentRepository repo){ this.repo = repo; }


    @Transactional
    public PageContent getOrCreate(String slug, String title, String defaultHtml){
        return repo.findBySlug(slug).orElseGet(() -> {
            PageContent pc = new PageContent();
            pc.setSlug(slug);
            pc.setTitle(title);
            pc.setContent(defaultHtml);
            return repo.save(pc);
        });
    }


    @Transactional(readOnly = true)
    public PageContent get(String slug){
        return repo.findBySlug(slug).orElse(null);
    }


    @Transactional
    public PageContent update(String slug, String title, String html){
        PageContent pc = repo.findBySlug(slug).orElseThrow();
        pc.setTitle(title);
        pc.setContent(html);
        return repo.save(pc);
    }
}