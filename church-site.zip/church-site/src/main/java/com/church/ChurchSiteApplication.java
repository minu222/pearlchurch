package com.church;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChurchSiteApplication {

    public static void main(String[] args) {
        SpringApplication.run(ChurchSiteApplication.class, args);
        System.out.println("server started!");
    }

}
