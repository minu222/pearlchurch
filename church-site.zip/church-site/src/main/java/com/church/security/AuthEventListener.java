package com.church.security;


import com.church.domain.AccessLog;
import com.church.repository.AccessLogRepository;
import org.springframework.context.event.EventListener;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;


import jakarta.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;


@Component
public class AuthEventListener {
    private final AccessLogRepository logs;
    public AuthEventListener(AccessLogRepository logs){ this.logs = logs; }


    @EventListener
    public void onSuccess(AuthenticationSuccessEvent e){
        Object principal = e.getAuthentication().getPrincipal();
        if (!(principal instanceof CustomUserDetails cud)) return;
        HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        String ip = req.getRemoteAddr();
        String ua = req.getHeader("User-Agent");


        AccessLog log = new AccessLog();
        log.setUserId(cud.getId());
        log.setChurchNo(cud.getChurchNo());
        log.setDisplayName(cud.getDisplayName());
        log.setIp(ip);
        log.setUserAgent(ua);
        log.setLoginAt(LocalDateTime.now());
        logs.save(log);
    }
}