package com.church.security;


import com.church.domain.AdminUser;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;


import java.util.Collection;
import java.util.List;


public class CustomUserDetails implements UserDetails {
    private final Long id;
    private final String churchNo;
    private final String displayName;
    private final String password;
    private final List<GrantedAuthority> authorities;


    public CustomUserDetails(AdminUser u){
        this.id = u.getId();
        this.churchNo = u.getChurchNo();
        this.displayName = u.getDisplayName();
        this.password = u.getPassword();
        this.authorities = List.of(new SimpleGrantedAuthority("ROLE_" + u.getRole().name()));
    }


    public Long getId(){ return id; }
    public String getChurchNo(){ return churchNo; }
    public String getDisplayName(){ return displayName; }


    @Override public Collection<? extends GrantedAuthority> getAuthorities() { return authorities; }
    @Override public String getPassword() { return password; }
    @Override public String getUsername() { return churchNo; } // 교회번호를 username으로 사용
    @Override public boolean isAccountNonExpired() { return true; }
    @Override public boolean isAccountNonLocked() { return true; }
    @Override public boolean isCredentialsNonExpired() { return true; }
    @Override public boolean isEnabled() { return true; }
}