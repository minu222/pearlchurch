package com.church.security;


import com.church.repository.AdminUserRepository;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


@Service
public class AdminUserDetailsService implements UserDetailsService {
    private final AdminUserRepository repo;
    public AdminUserDetailsService(AdminUserRepository repo){ this.repo = repo; }


    @Override
    public UserDetails loadUserByUsername(String churchNo) throws UsernameNotFoundException {
        return repo.findByChurchNo(churchNo)
                .map(CustomUserDetails::new)
                .orElseThrow(() -> new UsernameNotFoundException("관리자를 찾을 수 없습니다: " + churchNo));
    }
}