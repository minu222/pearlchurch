// 필요 시 공통 스크립트 작성
console.log("church-site loaded");