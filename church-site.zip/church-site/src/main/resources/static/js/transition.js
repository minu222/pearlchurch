document.addEventListener("DOMContentLoaded", function () {
    const body = document.body;

    // 마지막 페이지 타입 기억해 둔 값
    const lastPageType = sessionStorage.getItem("lastPageType");

    const isHome = body.classList.contains("page-home");
    const isSub  = body.classList.contains("page-sub");

    // 서브 페이지 진입 애니메이션
    if (isSub) {
        // 홈에서 왔으면 배경 확장 애니메이션
        if (lastPageType === "page-home") {
            body.classList.add("from-home");
        } else {
            // 서브에서 서브로 온 경우
            body.classList.add("from-sub");
        }

        // 다음 프레임에 animate-in 부여
        setTimeout(function () {
            body.classList.add("animate-in");
        }, 30);
    }

    // 홈(메인) 페이지 진입 애니메이션
    if (isHome) {
        // 서브에서 홈으로 돌아오는 경우에만 shrink 애니메이션
        if (lastPageType === "page-sub") {
            body.classList.add("from-sub"); // '서브에서 돌아왔다' 표시

            setTimeout(function () {
                body.classList.add("animate-in");
            }, 30);
        }
    }

    // 현재 페이지 타입을 다음 페이지를 위해 저장
    if (isHome) {
        sessionStorage.setItem("lastPageType", "page-home");
    } else if (isSub) {
        sessionStorage.setItem("lastPageType", "page-sub");
    }
});
